# include <stdio.h>
//inicio do projeto sempre tem que se iniciar deste modo

int main() {
    //aonde irar criar 4 variazeis floar indica que são armazenados numeros inteiros
    float P1, P2, P3, media_final;
    //aqui estamos printando na tele e chamando scanf aonde armezar dados e indicnando que os dados vao ser  /% que vai ser float &p1 indica que vai cer armezando algo no p1 
    printf ("digita a nota seu noia da prova 1:");
    scanf("%f",&P1);
      printf ("sera que você vai passar:\n");
    printf ("digita a nota seu noia da prova 2:" );
    scanf ("%f",&P2);
       printf ("se estudar as notas saem boas:\n");
    printf ("digita a nota seu noia da prova 3:");
    scanf  ("%f",&P3);
   
    
//variavel que armazenou os dados dos P1 P2 P3 P4 agora estão sendo somados
media_final = (P1 + P2 + P3) / 3;

//dados de saida na tela da media final junto com printf dizendo pra digirar a media final na tela junto com linha codigo %.2f que indica  as casas decimais ixibidas
printf("nao ponha a culpa na maconha nota final : %.2f\n", media_final);
return 0;
}
